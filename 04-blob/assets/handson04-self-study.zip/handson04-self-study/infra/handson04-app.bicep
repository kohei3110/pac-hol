targetScope = 'resourceGroup'

param location string = resourceGroup().location
param stem string
param storageName string
param registryName string
param image string
param clientIPv4 string
param validationSession string
param ownerId string = ''

var tags = {
  Purpose: 'AzureHandsOn'
  Session: '04'
  ValidationSession: validationSession
  Participant: ownerId
}

resource identity 'Microsoft.ManagedIdentity/userAssignedIdentities@2024-11-30' existing = {
  name: 'id-${stem}'
}
resource environment 'Microsoft.App/managedEnvironments@2026-07-01' existing = {
  name: 'cae-${stem}'
}
resource registry 'Microsoft.ContainerRegistry/registries@2025-11-01' existing = {
  name: registryName
}

resource app 'Microsoft.App/containerApps@2026-07-01' = {
  name: 'ca-${stem}'
  location: location
  tags: tags
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: { '${identity.id}': {} }
  }
  properties: {
    environmentId: environment.id
    workloadProfileName: 'Consumption'
    configuration: {
      activeRevisionsMode: 'Single'
      registries: [{ server: registry.properties.loginServer, identity: identity.id }]
      ingress: {
        external: true
        targetPort: 8080
        transport: 'http'
        allowInsecure: false
        ipSecurityRestrictions: [
          {
            name: 'classroom'
            description: 'Temporary network safeguard; not user authentication.'
            action: 'Allow'
            ipAddressRange: '${clientIPv4}/32'
          }
        ]
      }
    }
    template: {
      containers: [
        {
          name: 'upload-viz'
          image: image
          env: [
            { name: 'AZURE_STORAGE_ACCOUNT', value: storageName }
            { name: 'AZURE_CLIENT_ID', value: identity.properties.clientId }
          ]
          resources: { cpu: json('0.25'), memory: '0.5Gi' }
          probes: [
            {
              type: 'Readiness'
              httpGet: { path: '/healthz', port: 8080, scheme: 'HTTP' }
              initialDelaySeconds: 3
              periodSeconds: 10
            }
            {
              type: 'Liveness'
              httpGet: { path: '/healthz', port: 8080, scheme: 'HTTP' }
              initialDelaySeconds: 10
              periodSeconds: 30
            }
          ]
        }
      ]
      scale: { minReplicas: 0, maxReplicas: 1 }
    }
  }
}

output appFqdn string = app.properties.configuration.ingress.fqdn
