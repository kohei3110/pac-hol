targetScope = 'resourceGroup'

param location string = resourceGroup().location
@minLength(3)
@maxLength(10)
param ownerId string
param validationSession string

var tags = {
  Purpose: 'AzureHandsOn'
  Session: '04'
  Participant: ownerId
  ValidationSession: validationSession
}

module resources './handson04-resources.bicep' = {
  name: 'hol04-owned-resources'
  params: {
    location: location
    stem: 'hol04-${ownerId}'
    ownerId: ownerId
    tags: tags
  }
}

output registryName string = resources.outputs.registryName
output registryLoginServer string = resources.outputs.registryLoginServer
output storageName string = resources.outputs.storageName
output identityName string = resources.outputs.identityName
output environmentName string = resources.outputs.environmentName
